from setuptools import setup

setup(
    name="readinputs",
    version="1.0.1",
    description="read input module for advent of code",
    author="wjpark",
    author_email="wjpark11@gmail.com",
    url=None,
    py_modules=["readinputs"],
)
